'use client'

import { useState } from 'react'

const nav = ['Dashboard', 'Crear vídeo', 'Mis vídeos', 'Créditos']

export default function Home() {
  const [active, setActive] = useState('Dashboard')
  const [prompt, setPrompt] = useState('Crea un anuncio premium para este producto, con una apertura impactante y un CTA claro.')
  const [duration, setDuration] = useState('10s')
  const [quality, setQuality] = useState('1080p')
  const [generating, setGenerating] = useState(false)
  const [credits, setCredits] = useState(50)

  function generate() {
    if (credits < (quality === '1080p' ? 250 : 200)) return
    setGenerating(true)
    setCredits(c => c - (quality === '1080p' ? 250 : 200))
    setTimeout(() => setGenerating(false), 2200)
  }

  return <main className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">A</span><span>AdMotion <b>AI</b></span></div>
      <div className="workspace"><div className="avatar">A</div><div><strong>Mi espacio</strong><small>Plan Free</small></div><span className="chev">⌄</span></div>
      <nav>{nav.map((item, i) => <button key={item} onClick={() => setActive(item)} className={active === item ? 'active' : ''}><span className="nav-icon">{['⌂','✦','▣','◈'][i]}</span>{item}{item === 'Créditos' && <em>{credits}</em>}</button>)}</nav>
      <div className="sidebar-bottom"><button><span>⚙</span> Ajustes</button><button><span>?</span> Ayuda</button></div>
    </aside>

    <section className="content">
      <header className="topbar"><div><span className="eyebrow">AD CREATOR</span><h1>{active === 'Dashboard' ? 'Buenos días 👋' : active}</h1></div><div className="top-actions"><div className="credit-pill">✦ {credits} créditos</div><button className="upgrade">Mejorar plan</button><div className="user-dot">A</div></div></header>

      {active === 'Dashboard' && <>
        <section className="hero-card"><div className="hero-copy"><div className="sparkle">✦</div><h2>Convierte un producto<br/>en un <span>anuncio de vídeo</span></h2><p>Sube una imagen, describe la idea y deja que la IA haga el resto.</p><button className="primary" onClick={() => setActive('Crear vídeo')}>+ Crear nuevo vídeo <span>→</span></button></div><div className="hero-preview"><div className="mock-video"><div className="play">▶</div><div className="video-lines"><i></i><i></i><i></i></div><div className="product-orb">✦</div></div></div></section>
        <div className="section-title"><div><h3>Tu actividad</h3><p>Las últimas creaciones de tu espacio.</p></div><button className="text-btn" onClick={() => setActive('Mis vídeos')}>Ver todo →</button></div>
        <div className="video-grid">{['Glow Serum','Urban Sneakers','Smart Bottle'].map((name, i) => <article className="video-card" key={name}><div className={'thumb t'+i}><span>▶</span><small>{i === 0 ? '10s · 1080p' : i === 1 ? '5s · 720p' : '10s · 1080p'}</small></div><div className="card-meta"><div><strong>{name}</strong><small>Hoy · {i + 1} variantes</small></div><button>•••</button></div></article>)}</div>
      </>}

      {active === 'Crear vídeo' && <section className="creator"><div className="creator-head"><div><span className="eyebrow">NUEVA CREACIÓN</span><h2>Crea tu anuncio</h2><p>Una imagen + una buena idea. Nosotros hacemos el vídeo.</p></div><div className="credit-pill">Coste estimado · {quality === '1080p' ? 250 : 200} créditos</div></div><div className="creator-grid"><div className="upload-box"><div className="upload-icon">↑</div><h3>Sube tu producto</h3><p>Arrastra una imagen aquí o <u>elige un archivo</u></p><small>PNG, JPG o WEBP · hasta 10 MB</small></div><div className="settings-box"><label>Describe el anuncio</label><textarea value={prompt} onChange={e => setPrompt(e.target.value)} />
        <div className="two-col"><div><label>Duración</label><div className="segmented">{['5s','10s'].map(x => <button key={x} onClick={() => setDuration(x)} className={duration === x ? 'selected' : ''}>{x}</button>)}</div></div><div><label>Calidad</label><div className="segmented">{['720p','1080p'].map(x => <button key={x} onClick={() => setQuality(x)} className={quality === x ? 'selected' : ''}>{x}</button>)}</div></div></div><button className="generate" onClick={generate} disabled={generating}>{generating ? 'Generando…' : '✦ Generar anuncio'}<span>{generating ? '' : '→'}</span></button></div></div></section>}

      {active === 'Mis vídeos' && <section className="library"><div className="section-title"><div><h3>Tus vídeos</h3><p>Todos tus anuncios generados.</p></div><button className="primary small" onClick={() => setActive('Crear vídeo')}>+ Crear vídeo</button></div><div className="video-grid">{['Glow Serum','Urban Sneakers','Smart Bottle','Coffee Lab','Travel Case','Aura Headphones'].map((name, i) => <article className="video-card" key={name}><div className={'thumb t'+(i%3)}><span>▶</span><small>{i%2 ? '5s · 720p' : '10s · 1080p'}</small></div><div className="card-meta"><div><strong>{name}</strong><small>Generado recientemente</small></div><button>•••</button></div></article>)}</div></section>}

      {active === 'Créditos' && <section className="credits-page"><div className="balance-card"><span>CRÉDITOS DISPONIBLES</span><strong>{credits}</strong><p>Tu saldo actual</p><button className="primary">Comprar créditos →</button></div><div className="plans"><div><span>STARTER</span><h3>500 créditos</h3><strong>9,99 €<small>/mes</small></strong><button>Elegir plan</button></div><div className="featured"><span>CREATOR · MÁS POPULAR</span><h3>1.500 créditos</h3><strong>24,99 €<small>/mes</small></strong><button>Elegir plan</button></div><div><span>PRO</span><h3>5.000 créditos</h3><strong>59,99 €<small>/mes</small></strong><button>Elegir plan</button></div></div></section>}
    </section>
  </main>
}
