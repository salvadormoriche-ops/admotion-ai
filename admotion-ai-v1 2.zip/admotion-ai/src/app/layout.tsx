import './globals.css'

export const metadata = { title: 'AdMotion AI', description: 'Crea anuncios de vídeo con IA a partir de tu producto.' }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>
}
