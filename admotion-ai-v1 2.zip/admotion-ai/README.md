# AdMotion AI

Base V1 para SaaS de generación de anuncios de vídeo con IA.

## Stack
- Next.js App Router
- Supabase Auth/Database
- Vercel
- Stripe (pendiente de conectar)
- Proveedor de vídeo IA (pendiente de conectar)

## Variables
Copia `.env.example` a `.env.local` y añade:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

No pongas nunca una service-role/secret key en variables `NEXT_PUBLIC_*`.

## Desarrollo
```bash
npm install
npm run dev
```
